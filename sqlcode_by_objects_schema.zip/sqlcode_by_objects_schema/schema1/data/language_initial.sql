INSERT INTO "language" ("language_id", "name", "last_update") VALUES (1, 'English             ', '2006-02-15 10:02:19');
INSERT INTO "language" ("language_id", "name", "last_update") VALUES (2, 'Italian             ', '2006-02-15 10:02:19');
INSERT INTO "language" ("language_id", "name", "last_update") VALUES (3, 'Japanese            ', '2006-02-15 10:02:19');
INSERT INTO "language" ("language_id", "name", "last_update") VALUES (4, 'Mandarin            ', '2006-02-15 10:02:19');
INSERT INTO "language" ("language_id", "name", "last_update") VALUES (5, 'French              ', '2006-02-15 10:02:19');
INSERT INTO "language" ("language_id", "name", "last_update") VALUES (6, 'German              ', '2006-02-15 10:02:19');
