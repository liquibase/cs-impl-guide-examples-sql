INSERT INTO "store" ("store_id", "manager_staff_id", "address_id", "last_update") VALUES (1, 1, 1, '2006-02-15 09:57:12');
INSERT INTO "store" ("store_id", "manager_staff_id", "address_id", "last_update") VALUES (2, 2, 2, '2006-02-15 09:57:12');
