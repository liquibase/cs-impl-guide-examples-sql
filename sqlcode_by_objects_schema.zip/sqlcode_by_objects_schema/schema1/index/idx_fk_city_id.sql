CREATE INDEX "idx_fk_city_id" ON "address"("city_id");
