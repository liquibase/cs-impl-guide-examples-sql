DROP SEQUENCE "city_city_id_seq";
